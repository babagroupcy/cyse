import numpy as np

# Function to convert letters to numbers (A=0, B=1, ..., Z=25)
def text_to_numbers(text):
    return [ord(c) - ord('A') for c in text]

# Function to convert numbers back to letters
def numbers_to_text(numbers):
    return ''.join(chr(int(num) + ord('A')) for num in numbers)

# Function to encrypt using Hill Cipher
def hill_encrypt(plaintext, key_matrix):
    n = len(key_matrix)
    
    # Convert plaintext to uppercase and remove spaces
    plaintext = plaintext.replace(" ", "").upper()
    
    # Pad with 'X' if needed
    while len(plaintext) % n != 0:
        plaintext += 'X'
    
    ciphertext = ''
    
    for i in range(0, len(plaintext), n):
        block = plaintext[i:i+n]
        block_vector = np.array(text_to_numbers(block))
        
        # Multiply key matrix with block vector and mod 26
        encrypted_vector = np.dot(key_matrix, block_vector) % 26
        
        ciphertext += numbers_to_text(encrypted_vector)
    
    return ciphertext

# Example usage
if __name__ == "__main__":
    # Example 2x2 key matrix (must be invertible mod 26)
    key_matrix = np.array([[3, 3],
                           [2, 5]])

    plaintext = input("Enter the plaintext: ")
    ciphertext = hill_encrypt(plaintext, key_matrix)

    print("Encrypted text (Ciphertext):", ciphertext)

Example Output
Enter the plaintext: HELLO
Encrypted text (Ciphertext): HIOZHN
