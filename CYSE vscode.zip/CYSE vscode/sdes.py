## Objective
Implement S‑DES and validate encryption/decryption and key scheduling.

## Requirements
- Python 3.8+
- Terminal


"""
Simplified DES (S-DES) implementation in pure Python
Key size: 10 bits -> subkeys K1, K2 (8 bits)
Block size: 8 bits
"""

def permute(bits, table):
    return ''.join(bits[i-1] for i in table)

def left_shift(bits, n):
    n %= len(bits)
    return bits[n:] + bits[:n]

def xor(a, b):
    return ''.join('1' if x != y else '0' for x, y in zip(a, b))

def sbox_lookup(bits, sbox):
    row = int(bits[0] + bits[3], 2)
    col = int(bits[1:3], 2)
    return f"{sbox[row][col]:02b}"

P10 = [3,5,2,7,4,10,1,9,8,6]
P8  = [6,3,7,4,8,5,10,9]
IP  = [2,6,3,1,4,8,5,7]
IP_INV = [4,1,3,5,7,2,8,6]
EP  = [4,1,2,3,2,3,4,1]
P4  = [2,4,3,1]

S0 = [
    [1,0,3,2],
    [3,2,1,0],
    [0,2,1,3],
    [3,1,3,2]
]

S1 = [
    [0,1,2,3],
    [2,0,1,3],
    [3,0,1,0],
    [2,1,0,3]
]

def generate_subkeys(key10):
    if len(key10) != 10 or any(c not in '01' for c in key10):
        raise ValueError("key10 must be a 10-bit string")
    p10 = permute(key10, P10)
    L, R = p10[:5], p10[5:]
    L1, R1 = left_shift(L,1), left_shift(R,1)
    K1 = permute(L1+R1, P8)
    L2, R2 = left_shift(L1,2), left_shift(R1,2)
    K2 = permute(L2+R2, P8)
    return K1, K2

def fk(bits8, subkey):
    L, R = bits8[:4], bits8[4:]
    ep = permute(R, EP)
    x = xor(ep, subkey)
    l4, r4 = x[:4], x[4:]
    s0o = sbox_lookup(l4, S0)
    s1o = sbox_lookup(r4, S1)
    p4 = permute(s0o + s1o, P4)
    return xor(L, p4) + R

def switch(bits8):
    return bits8[4:] + bits8[:4]

def encrypt_block(plain8, key10):
    if len(plain8)!=8 or any(c not in '01' for c in plain8):
        raise ValueError("plain8 must be 8-bit string")
    K1,K2 = generate_subkeys(key10)
    s = permute(plain8, IP)
    s = fk(s, K1)
    s = switch(s)
    s = fk(s, K2)
    return permute(s, IP_INV)

def decrypt_block(cipher8, key10):
    if len(cipher8)!=8 or any(c not in '01' for c in cipher8):
        raise ValueError("cipher8 must be 8-bit string")
    K1,K2 = generate_subkeys(key10)
    s = permute(cipher8, IP)
    s = fk(s, K2)
    s = switch(s)
    s = fk(s, K1)
    return permute(s, IP_INV)

def byte_to_bits(b): return f"{b:08b}"
def bits_to_byte(bits8): return int(bits8,2)

def ecb_encrypt_bytes(data: bytes, key10: str) -> bytes:
    return bytes(bits_to_byte(encrypt_block(byte_to_bits(b), key10)) for b in data)

def ecb_decrypt_bytes(data: bytes, key10: str) -> bytes:
    return bytes(bits_to_byte(decrypt_block(byte_to_bits(b), key10)) for b in data)

def _self_test():
    key="1010000010"
    pt=b"S-DES demo!"
    ct=ecb_encrypt_bytes(pt,key)
    rt=ecb_decrypt_bytes(ct,key)
    assert rt==pt
    return {"cipher_hex": ct.hex(), "ok": True}

if __name__ == "__main__":
    import argparse, sys
    p=argparse.ArgumentParser()
    p.add_argument("mode", choices=["enc","dec"])
    p.add_argument("key10")
    p.add_argument("-i","--infile", default="-")
    p.add_argument("-o","--outfile", default="-")
    a=p.parse_args()
    if len(a.key10)!=10 or any(c not in "01" for c in a.key10):
        sys.exit("key must be 10 bits of 0/1")
    data = sys.stdin.buffer.read() if a.infile=="-" else open(a.infile,"rb").read()
    out = ecb_encrypt_bytes(data,a.key10) if a.mode=="enc" else ecb_decrypt_bytes(data,a.key10)
    if a.outfile=="-":
        sys.stdout.buffer.write(out)
    else:
        open(a.outfile,"wb").write(out)
