# Cell 1 — install deps (run once)
!pip install flask flask-ngrok requests

# Cell 2 — Flask app that demonstrates IP-based auth and X-Forwarded-For handling
from flask import Flask, request, jsonify
import logging
from datetime import datetime
import threading

app = Flask(__name__)

# Setup simple logging to file
logging.basicConfig(filename='ip_auth_lab.log',
                    level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')

# Allowed IP (simulate allowed client)
ALLOWED_IPS = {"10.0.0.1", "127.0.0.1"}  # we'll simulate different remote_addrs in tests

def log_request(allowed):
    info = {
        "time": datetime.utcnow().isoformat()+"Z",
        "remote_addr": request.remote_addr,
        "x_forwarded_for": request.headers.get("X-Forwarded-For"),
        "path": request.path,
        "allowed": allowed
    }
    logging.info(str(info))

# Middleware-style route
@app.route("/", methods=["GET"])
def index():
    # True server-side check using request.remote_addr
    remote = request.remote_addr or ""
    if remote in ALLOWED_IPS:
        log_request(True)
        return "<h1>Access granted — your IP: {}</h1>".format(remote), 200

    # Example: behind a reverse proxy - trusting X-Forwarded-For (dangerous if untrusted)
    xff = request.headers.get("X-Forwarded-For")
    if xff:
        # take first entry
        client_ip = xff.split(",")[0].strip()
        if client_ip in ALLOWED_IPS:
            log_request(True)
            return "<h1>Access granted via X-Forwarded-For: {}</h1>".format(client_ip), 200

    log_request(False)
    return "<h1>403 Forbidden — your IP: {}</h1>".format(remote), 403

@app.route("/logs")
def show_logs():
    # show last 200 lines
    with open('ip_auth_lab.log') as f:
        lines = f.readlines()[-200:]
    return "<pre>{}</pre>".format("".join(lines).replace("<","&lt;")), 200

def run_app():
    # Run Flask; on Colab we will rely on flask-ngrok to expose URL OR use local serve trick.
    app.run(host='0.0.0.0', port=8080, debug=False)

# Run in background thread so subsequent test cells can run
thread = threading.Thread(target=run_app, daemon=True)
thread.start()
print("Flask app started on port 8080")


# Cell 3 — create helper test functions (simulate different clients)
import requests
import time

BASE = "http://127.0.0.1:8080"  # within Colab
time.sleep(1)  # give server a second

def test_request(sim_remote=None, xff=None):
    """
    sim_remote: used to simulate request.remote_addr for demo — but requests from Colab will actually
                originate from the notebook environment. We'll show two approaches below:
                  1) direct requests -> real remote address (Colab host)
                  2) simulate X-Forwarded-For header to show how proxies/headers can be spoofed
    xff: value for X-Forwarded-For header (string)
    """
    headers = {}
    if xff:
        headers["X-Forwarded-For"] = xff
    try:
        r = requests.get(BASE+"/", headers=headers, timeout=5)
        return r.status_code, r.text
    except Exception as e:
        return None, str(e)

# Test 1: normal request (will be from Colab host IP)
print("Normal request (no XFF):", test_request())

# Test 2: simulate allowed client via X-Forwarded-For header
print("Spoof X-Forwarded-For to allowed IP 10.0.0.1:",
      test_request(xff="10.0.0.1"))

# Test 3: spoof to denied IP
print("Spoof X-Forwarded-For to denied IP 192.168.1.50:",
      test_request(xff="192.168.1.50"))

# Show logs page (to inspect)
print("\nLogs page (recent entries):")
print(requests.get(BASE+"/logs").text[:1000])

# Optional: If you want to expose the Flask app to the internet from Colab,
# use flask-ngrok. Note: this opens a public URL — don't expose sensitive tests.
from flask_ngrok import run_with_ngrok
# To re-run with ngrok, you would modify the Flask startup to call run_with_ngrok(app),
# but for simplicity we ran locally above. If you want public URL, re-start with run_with_ngrok.
