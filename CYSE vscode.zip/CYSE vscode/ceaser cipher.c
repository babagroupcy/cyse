//ceaser cipher c code

#include <stdio.h>
#include <ctype.h>  // for isalpha(), isupper(), islower()
#include <string.h> // for strlen()

void encrypt(char text[], int key) {
    for (int i = 0; i < strlen(text); i++) {
        char ch = text[i];

        if (isupper(ch)) {
            text[i] = ((ch - 'A' + key) % 26) + 'A';
        } 
        else if (islower(ch)) {
            text[i] = ((ch - 'a' + key) % 26) + 'a';
        }
    }
}

void decrypt(char text[], int key) {
    for (int i = 0; i < strlen(text); i++) {
        char ch = text[i];

        if (isupper(ch)) {
            text[i] = ((ch - 'A' - key + 26) % 26) + 'A';
        } 
        else if (islower(ch)) {
            text[i] = ((ch - 'a' - key + 26) % 26) + 'a';
        }
    }
}

int main() {
    char text[100];
    int key, choice;

    printf("Enter text: ");
    fgets(text, sizeof(text), stdin);
    text[strcspn(text, "\n")] = '\0'; // remove newline

    printf("Enter key (1-25): ");
    scanf("%d", &key);

    printf("Choose operation:\n1. Encrypt\n2. Decrypt\nEnter choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        encrypt(text, key);
        printf("Encrypted text: %s\n", text);
    } 
    else if (choice == 2) {
        decrypt(text, key);
        printf("Decrypted text: %s\n", text);
    } 
    else {
        printf("Invalid choice!\n");
    }

    return 0;
}
//       output

// Enter text: HelloWorld
// Enter key (1-25): 3
// Choose operation:
// 1. Encrypt
// 2. Decrypt
// Enter choice: 1
// Encrypted text: KhoorZruog


//Python Code:
def caesar_cipher(text, shift, mode='encrypt'):
    result = ""
    
    # Adjust shift for decryption
    if mode == 'decrypt':
        shift = -shift
    
    for char in text:
        if char.isalpha():  # Check if it's a letter
            # Handle uppercase and lowercase separately
            start = ord('A') if char.isupper() else ord('a')
            
            # Shift character and wrap around using modulo 26
            result += chr((ord(char) - start + shift) % 26 + start)
        else:
            # Non-alphabetical characters remain unchanged
            result += char
    
    return result

// # Example usage
// plaintext = "Hello World"
// shift_value = 3

// encrypted = caesar_cipher(plaintext, shift_value, mode='encrypt')
// decrypted = caesar_cipher(encrypted, shift_value, mode='decrypt')

// print(f"Plaintext : {plaintext}")
// print(f"Encrypted : {encrypted}")
// print(f"Decrypted : {decrypted}")

// Plaintext : Hello World
// Encrypted : Khoor Zruog
// Decrypted : Hello World
