# ===============================
# RSA Implementation in Python
# (Educational Demo – Raw RSA)
# ===============================

import secrets, math

# --- Miller-Rabin primality test ---
def is_probable_prime(n, k=40):
    if n < 2:
        return False
    small_primes = [2,3,5,7,11,13,17,19,23,29]
    for p in small_primes:
        if n % p == 0:
            return n == p
    s, d = 0, n-1
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(k):
        a = secrets.randbelow(n-3) + 2
        x = pow(a, d, n)
        if x == 1 or x == n-1:
            continue
        for _r in range(s-1):
            x = pow(x, 2, n)
            if x == n-1:
                break
        else:
            return False
    return True

# --- Prime generation ---
def generate_prime(bits):
    while True:
        p = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if is_probable_prime(p):
            return p

# --- Extended GCD / modular inverse ---
def egcd(a, b):
    if b == 0: return (a,1,0)
    g, x1, y1 = egcd(b, a % b)
    return (g, y1, x1 - (a//b)*y1)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1: raise ValueError("No modular inverse")
    return x % m

# --- RSA key generation ---
def generate_rsa_keypair(bits=512, e=65537):
    half = bits // 2
    while True:
        p = generate_prime(half)
        q = generate_prime(bits - half)
        if p == q: continue
        n = p * q
        phi = (p-1)*(q-1)
        if math.gcd(e, phi) == 1:
            d = modinv(e, phi)
            return {"public": (n, e), "private": (n, d)}

# --- Helpers for conversion ---
def bytes_to_int(b): return int.from_bytes(b, "big")
def int_to_bytes(i):
    length = (i.bit_length()+7)//8
    return i.to_bytes(length, "big")

# --- RSA operations ---
def rsa_encrypt(pub, plaintext_bytes):
    n, e = pub
    m = bytes_to_int(plaintext_bytes)
    if m >= n: raise ValueError("Message too large!")
    return pow(m, e, n)

def rsa_decrypt(priv, ciphertext):
    n, d = priv
    m = pow(ciphertext, d, n)
    return int_to_bytes(m)

def rsa_sign(priv, message_bytes):
    n, d = priv
    m = bytes_to_int(message_bytes)
    return pow(m, d, n)

def rsa_verify(pub, message_bytes, sig):
    n, e = pub
    return bytes_to_int(message_bytes) == pow(sig, e, n)

# ===============================
# DEMO
# ===============================
print("Generating RSA keys (this may take a moment)...")
keys = generate_rsa_keypair(bits=512)   # use 1024/2048 for stronger security
pub, priv = keys["public"], keys["private"]
print("Public key (n bit-length):", pub[0].bit_length())

message = b"Hello RSA in Colab!"
print("\nOriginal message:", message)

# Encrypt/Decrypt
ciphertext = rsa_encrypt(pub, message)
print("Ciphertext (int):", ciphertext)
decrypted = rsa_decrypt(priv, ciphertext)
print("Decrypted message:", decrypted)

# Sign/Verify
signature = rsa_sign(priv, message)
print("\nSignature (int):", signature)
print("Signature valid?", rsa_verify(pub, message, signature))













# =====================================
# RSA Step-by-Step Example (Small Numbers)
# =====================================

import math

# Step 1: Choose two prime numbers
p = 61
q = 53
print("Step 1: Choose primes p =", p, "and q =", q)

# Step 2: Compute n = p * q
n = p * q
print("Step 2: Compute n = p * q =", n)

# Step 3: Compute Euler’s totient φ(n) = (p-1)(q-1)
phi = (p-1) * (q-1)
print("Step 3: φ(n) =", phi)

# Step 4: Choose public exponent e (1 < e < φ(n), gcd(e, φ(n))=1)
e = 17
print("Step 4: Choose public exponent e =", e)

# Step 5: Compute private exponent d (modular inverse of e mod φ(n))
def egcd(a, b):
    if b == 0: return (a, 1, 0)
    g, x1, y1 = egcd(b, a % b)
    return (g, y1, x1 - (a//b) * y1)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception("No modular inverse")
    return x % m

d = modinv(e, phi)
print("Step 5: Compute private exponent d =", d)

# Keys
public_key = (n, e)
private_key = (n, d)
print("\nPublic key:", public_key)
print("Private key:", private_key)

# Step 6: Encryption
M = 65  # our message as a number
print("\nStep 6: Original message (M) =", M)
C = pow(M, e, n)
print("Encrypted ciphertext (C) =", C)

# Step 7: Decryption
M_decrypted = pow(C, d, n)
print("Step 7: Decrypted message (M) =", M_decrypted)

# Step 8: Signature
S = pow(M, d, n)  # sign message
print("\nStep 8: Signature (S) =", S)

# Step 9: Verification
verified = pow(S, e, n)
print("Step 9: Verification result =", verified)
print("Signature valid?", verified == M)
