Experiment 1: Study of Wireless Network Components & Mobile Security Apps
Course: B.Tech (Cybersecurity Lab – 2nd Year)
Type: Theoretical + Practical
Duration: 2 Lab Hours

Objective:
To understand the key components of a wireless network (Wi-Fi) and explore the features of a mobile security app used to protect smartphones from cyber threats.

Part A: Understanding Wireless Network Components
1. What is a Wireless Network?
A wireless network allows devices to connect and communicate without using physical cables. It uses radio frequency (RF) to transmit data between devices.
2. Key Components of a Wireless Network:
•	Router: Connects local devices to the internet and manages traffic between them.
•	Access Point: Extends Wi-Fi coverage; provides wireless access to wired networks.
•	Wireless Adapter: Hardware (built-in or external) in laptops/phones enabling Wi-Fi connection.
•	SSID (Network Name): Name assigned to a wireless network.
•	Antenna: Sends and receives wireless signals.
•	Modem: Converts analog signal to digital (used with ISPs for internet access).
3. Types of Wireless Networks:
•	Wi-Fi (WLAN): Used in homes, colleges, offices
•	Bluetooth: Short-range communication
•	WiMAX: Wide-area wireless networks
•	Hotspots: Public Wi-Fi access points
4. Common Wireless Network Vulnerabilities:
•	Weak passwords
•	Unsecured or open networks
•	Outdated firmware
•	Evil Twin Attacks (fake access point)
•	Packet sniffing by attackers

Part B: Mobile Security Apps
1. What is a Mobile Security App?
Protects smartphones from:
•	Malware
•	Phishing
•	Data theft
•	Spyware
•	Unsafe websites
2. Examples of Mobile Security Apps:
•	Avast Mobile Security
•	Kaspersky Mobile Antivirus
•	Norton Mobile Security
•	Bitdefender Mobile Security
•	McAfee Mobile Security
3. Features to Analyze:
•	Real-Time Protection: Scans apps and files for malware.
•	Anti-Theft: Locates/locks phone if lost or stolen.
•	App Lock: Locks apps with PIN/fingerprint.
•	Web Protection: Blocks malicious/phishing sites.
•	Wi-Fi Security: Detects fake or insecure networks.
•	Privacy Advisor: Warns about app permissions.
•	Junk Cleaner: Clears cache for performance.

4. Student Task in Lab:
•	Install one mobile security app (e.g., Avast or Kaspersky).
•	Explore and document features.
•	Take screenshots of key features (dashboard, scan result, settings).
•	Create a comparison table with another app (optional).

Suggested Report Format (Lab Output):
1.	Title
2.	Objective
3.	Theory
4.	Steps Performed
5.	Screenshots
6.	Comparison Table (Optional)
7.	Conclusion

Real-Life Analogy:
•	A Wi-Fi router is like a post office, delivering data to the correct recipient.
•	A mobile security app is like a security guard, checking who’s safe before letting them in.

