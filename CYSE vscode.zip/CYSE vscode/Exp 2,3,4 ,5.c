Student Handout
Experiment -2 
Lab Practical: Firewall Security in Windows
Objective:
To understand how a firewall functions as a security mechanism in a networked environment and to configure firewall settings in the Windows operating system to monitor and control incoming and outgoing network traffic.
Theory:
A firewall is a system (hardware or software) designed to prevent unauthorized access to or from a private network. It inspects incoming and outgoing traffic based on predefined security rules. Firewalls are a critical component in modern cybersecurity frameworks.
Key Functions of a Firewall:
•	- Packet filtering
•	- Port blocking
•	- Application-level filtering
•	- Network Address Translation (NAT)
•	- Logging and alerts
•	- Prevention of unauthorized access
Windows Firewall (now called Windows Defender Firewall) is a built-in tool that helps filter network traffic and block potentially harmful applications or connections.
Requirements:
•	- A system running Windows 10 or 11
•	- Administrator privileges
•	- Internet connectivity (optional, for testing rules)
Procedure:
1. Open Windows Defender Firewall:
   - Go to Control Panel > System and Security > Windows Defender Firewall
   - Alternatively, press Win + R, type firewall.cpl, and press Enter.
2. View Firewall Status:
   - Check whether the firewall is turned on for Domain, Private, and Public networks.
   - Click 'Turn Windows Defender Firewall on or off' to toggle settings.
3. Allow or Block an App Through the Firewall:
   - Click 'Allow an app or feature through Windows Defender Firewall'.
   - Click 'Change settings' > Check/Uncheck apps to allow/block them on private/public networks.
4. Create Inbound and Outbound Rules:
   - Go to Advanced settings (left panel).
   - In Windows Defender Firewall with Advanced Security window, choose Inbound or Outbound Rules > New Rule > follow prompts to define program, port, action, and name the rule.
5. Monitoring and Logging:
   - Under Monitoring, view the Active Rules, Firewall Policies, and Security Associations.
   - View logging under Properties > Logging.
Observation Table (Example):
Rule Type	Direction	Protocol	Port	Action	Result
Application	Inbound	All	N/A	Block	Chrome blocked on public net
Port-based	Outbound	TCP	80	Block	HTTP access blocked
Application	Inbound	All	N/A	Allow	Zoom allowed
Conclusion:
Students learned how to view, configure, and monitor firewall settings in Windows. They understood how firewalls contribute to network security by controlling traffic based on predefined rules and policies.
Viva Questions:
1. What is the main function of a firewall?
2. What is the difference between inbound and outbound rules?
3. Can a firewall prevent all cyber threats?
4. What happens when a port is blocked by a firewall?
5. How do application rules differ from port rules?







Student Handout
Experiment – 3 
Lab Practical: Ensuring Security of a Web Browser (Google Chrome)
Objective:
To study and perform steps to enhance the security and privacy of a commonly used web browser, specifically Google Chrome, in order to minimize the risk of cyber threats, tracking, and unauthorized data access.
Theory:
Web browsers are a common entry point for cyber threats such as phishing attacks, malicious scripts, and tracking technologies. Ensuring browser security helps protect users’ sensitive data, prevent unauthorized access, and maintain user privacy online.
Key Concepts in Browser Security:
•	- HTTPS enforcement
•	- Managing cookies and site data
•	- Controlling extensions and plugins
•	- Enabling safe browsing features
•	- Blocking pop-ups and trackers
•	- Regular software updates
Requirements:
•	- A system with Google Chrome browser installed
•	- Internet connectivity (optional for testing)
Procedure:
1. Open Google Chrome and navigate to 'Settings'.
2. Under 'Privacy and security', review and enable the following:
   - Clear browsing data regularly
   - Block third-party cookies
   - Enable 'Do Not Track' request
   - Use Secure DNS
3. Click on 'Security' and make sure Safe Browsing is set to 'Enhanced protection'.
4. Navigate to 'Site settings' and restrict permissions such as:
   - Location access
   - Camera and microphone
   - Notifications
   - Background sync
5. Manage Extensions:
   - Go to 'chrome://extensions/'
   - Remove or disable suspicious or unused extensions
6. Update Chrome:
   - Go to 'Help > About Google Chrome' to ensure the browser is up to date.
7. Optional:
   - Install a trusted privacy-focused extension (e.g., uBlock Origin, HTTPS Everywhere) for added security.
Observation Table (Example):
Security Feature	Configuration	Status/Result
Safe Browsing	Enhanced Protection Enabled	Phishing protection active
Cookies	Block third-party cookies	Tracking prevented
Permissions	Microphone/Camera Disabled	Unauthorized access blocked
Extensions	Removed suspicious extensions	Improved performance and security
Conclusion:
Students were able to identify and configure key settings in the Google Chrome browser to improve its security. These steps are essential for maintaining privacy and protecting against common browser-based attacks.
Viva Questions:
1. Why is browser security important in today’s digital world?
2. What is the difference between basic and enhanced Safe Browsing in Chrome?
3. How do third-party cookies affect user privacy?
4. What are some examples of risky browser extensions?
5. How can a user know if their Chrome browser is up to date?










Student Handout
Experiment 4
Lab Practical: Study of System Threat Attacks – DoS, Sniffing and Spoofing
Objective:
To study and understand different types of system threat attacks including Denial of Service (DoS), Sniffing, and Spoofing, and learn the basic principles behind how these attacks are executed and prevented.
Theory:
System threats such as DoS, sniffing, and spoofing are critical concerns in cybersecurity. These attacks aim to compromise the availability, confidentiality, or integrity of systems and networks.
1. Denial of Service (DoS):
•	A DoS attack aims to make a system or network resource unavailable to its intended users by overwhelming it with traffic.
•	Examples: ICMP Flood, SYN Flood, HTTP Flood
2. Sniffing:
•	Sniffing refers to monitoring and capturing network packets in transit to extract sensitive information.
•	Tools: Wireshark, tcpdump
3. Spoofing:
•	Spoofing involves impersonating another device or user on a network to gain unauthorized access.
•	Types: IP spoofing, ARP spoofing, Email spoofing
Requirements:
•	- A system with administrator privileges
•	- Wireshark or similar packet capture tool
•	- Access to a local test network or virtual environment
Procedure:
1. Study Denial of Service (DoS) Attack:
   - Open a test web server or service.
   - Use a DoS simulation tool (e.g., LOIC in a test environment).
   - Observe resource utilization during the attack.
2. Sniffing with Wireshark:
   - Open Wireshark and start capturing on an active network interface.
   - Analyze captured packets for information such as usernames, passwords (if unencrypted), and IP addresses.
3. Simulating Spoofing:
   - Use tools like 'arpspoof' or simulate in packet crafting software (test setup).
   - Demonstrate spoofing by redirecting network traffic or mimicking IP addresses.
4. Discuss the ethical considerations and ensure activities are done in isolated/test environments only.
Observation Table (Example):
Attack Type	Tool Used	Method	Observation
DoS	LOIC (test)	Flooding test server	High CPU/memory usage observed
Sniffing	Wireshark	Captured packets on LAN	Visible IP, DNS, and some plaintext data
Spoofing	arpspoof (test)	Impersonated IP in test network	Traffic misdirection or data capture
Conclusion:
Through this practical, students gained an understanding of common network and system threats including Denial of Service, sniffing, and spoofing. They observed how these attacks can be simulated and analyzed in a controlled environment and learned the importance of defensive strategies against such threats.
Viva Questions:
1. What is the primary goal of a Denial of Service (DoS) attack?
2. How does sniffing violate network confidentiality?
3. What is IP spoofing and how is it carried out?
4. Why is it important to simulate attacks only in test environments?
5. Name any two tools used for sniffing and spoofing attacks.








Student Handout
Experiment 5
Lab Practical: Study of Techniques Used for Web-Based Password Capturing
Objective:
To study the various techniques used for capturing passwords through web-based attacks and understand how such attacks are performed and mitigated in a controlled, ethical, and educational environment.
Theory:
Web-based password capturing is a technique used by attackers to steal user credentials through deceptive web interfaces or packet interception. Understanding how these attacks occur is essential for building secure web applications and educating users against phishing and insecure practices.
Common Techniques for Password Capturing:
•	- Phishing pages designed to mimic legitimate login forms
•	- Keyloggers injected via malicious scripts or extensions
•	- Man-in-the-Middle (MitM) attacks capturing traffic on insecure HTTP connections
•	- Browser-based autofill exploitations
Requirements:
•	- Test web server or browser simulation environment
•	- Wireshark or Burp Suite (Community Edition)
•	- Sample phishing HTML page (offline)
•	- Virtual machine (preferred for safety)
Procedure:
1. Open a virtual lab environment or isolated test system.
2. Demonstrate a phishing attack:
   - Create a fake login page (HTML form) mimicking a known service.
   - Host it on a local server.
   - Observe form data capture (username/password).
3. Monitor password fields using Burp Suite:
   - Intercept browser requests while logging in to a test website.
   - Observe form field data in HTTP request.
4. Demonstrate insecure form transmission:
   - Create a simple login page without HTTPS.
   - Use Wireshark to capture unencrypted credentials on the network (test LAN).
5. Discuss best practices for password protection:
   - Use HTTPS, avoid form-based credential caching, and educate users about phishing signs.
Observation Table (Example):
Technique	Tool Used	Observation
Phishing Page	HTML/Browser	Captured test credentials submitted to fake page
HTTP Form Interception	Burp Suite	Observed password in HTTP POST body
Packet Sniffing	Wireshark	Plaintext credentials visible on HTTP transmission
Conclusion:
Students explored techniques used for capturing web-based passwords using simulated phishing attacks, HTTP sniffing, and request interception. The session emphasized ethical practices and highlighted the importance of secure design and awareness in preventing such vulnerabilities.
Viva Questions:
1. What is the primary difference between phishing and sniffing attacks?
2. How does HTTPS protect against web-based password capturing?
3. What role does Burp Suite play in web security testing?
4. What are some common signs of phishing websites?
5. Why is a virtual machine recommended for testing such techniques?

